#include "../include/Vehicle.h"
#include <cmath>
#include <sstream>
#include <iomanip>

Vehicle::Vehicle()
    : engineOn(false),
      doorLocked(false),
      parkingBrake(true),  // Parking brake is on by default
      seatbeltOn(false),
      speed(0.0),
      currentMaxSpeed(0.0),
      brakePressTime(0.0),
      weight(1800.0) {  // 1800 kg as per Database.md
    
    // Initialize current max speed based on driving mode
    currentMaxSpeed = drivingMode.getMaxSpeedLimit();
    
    // Initialize sensors
    initializeSensors();
}

Vehicle::~Vehicle() {
    // Cleanup if needed
}

// Getters
bool Vehicle::isEngineOn() const {
    return engineOn;
}

bool Vehicle::isDoorLocked() const {
    return doorLocked;
}

bool Vehicle::isParkingBrakeOn() const {
    return parkingBrake;
}

bool Vehicle::isSeatbeltOn() const {
    return seatbeltOn;
}

double Vehicle::getSpeed() const {
    return speed;
}

double Vehicle::getCurrentMaxSpeed() const {
    return currentMaxSpeed;
}

double Vehicle::getBrakePressTime() const {
    return brakePressTime;
}

double Vehicle::getWeight() const {
    return weight;
}

Engine& Vehicle::getEngine() {
    return engine;
}

Battery& Vehicle::getBattery() {
    return battery;
}

DrivingMode& Vehicle::getDrivingMode() {
    return drivingMode;
}

SafetySystem& Vehicle::getSafetySystem() {
    return safetySystem;
}

EnvironmentalCondition& Vehicle::getEnvironment() {
    return environment;
}

FaultSimulation& Vehicle::getFaultSim() {
    return faultSim;
}

Display& Vehicle::getDisplay() {
    return display;
}

// Setters
void Vehicle::setEngineOn(bool state) {
    engineOn = state;
}

void Vehicle::setDoorLocked(bool state) {
    doorLocked = state;
}

void Vehicle::setParkingBrake(bool state) {
    parkingBrake = state;
}

void Vehicle::setSeatbeltOn(bool state) {
    seatbeltOn = state;
}

void Vehicle::setSpeed(double newSpeed) {
    // Ensure speed is non-negative and doesn't exceed current max speed
    speed = std::max(0.0, std::min(newSpeed, currentMaxSpeed));
}

void Vehicle::setBrakePressTime(double time) {
    brakePressTime = time;
}

void Vehicle::setWeight(double weight) {
    this->weight = weight;
}

bool Vehicle::startEngine() {
    // Check if doors are locked as per Operation.md requirement 7
    if (!doorLocked) {
        display.addMessage("Doors not locked", MessageType::WARNING);
        return false;
    }
    
    // Check if parking brake is released as per Operation.md requirement 1
    if (parkingBrake) {
        if (brakePressTime < 3.0) {
            display.addMessage("Press brake for 3 seconds to release parking brake", MessageType::WARNING);
            return false;
        } else {
            // Release parking brake after 3 seconds of brake press
            parkingBrake = false;
        }
    }
    
    // Start the engine
    engine.start();
    engineOn = true;
    
    // Reset brake press time
    brakePressTime = 0.0;
    
    return true;
}

void Vehicle::stopEngine() {
    // Stop the engine
    engine.stop();
    engineOn = false;
    
    // Set parking brake
    parkingBrake = true;
    
    // Reset speed
    speed = 0.0;
}

double Vehicle::accelerate(double amount) {
    if (!engineOn) {
        return 0.0;
    }
    
    // Ensure amount is between 0 and 1
    amount = std::max(0.0, std::min(1.0, amount));
    
    // Calculate power based on throttle position and driving mode
    double power = engine.updatePower(amount, drivingMode.getCurrentMode());
    
    // Calculate acceleration based on power and weight
    double acceleration = engine.calculateAcceleration(weight);
    
    // Update speed (assuming deltaTime = 1 second for simplicity)
    double oldSpeed = speed;
    double newSpeed = speed + acceleration * 3.6;  // Convert m/s² to km/h
    
    // Ensure speed doesn't exceed current max speed
    setSpeed(newSpeed);
    
    // Check seatbelt when moving
    checkSeatbelt();
    
    // Check for high speed warning
    checkHighSpeed();
    
    // Discharge battery based on power usage
    battery.discharge(power / battery.getCapacity() * 0.01);
    
    return speed - oldSpeed;
}

double Vehicle::brake(double amount) {
    if (!engineOn) {
        return 0.0;
    }
    
    // Ensure amount is between 0 and 1
    amount = std::max(0.0, std::min(1.0, amount));
    
    // Calculate deceleration based on brake force
    double deceleration = amount * 5.0;  // Max deceleration of 5 m/s²
    
    // Activate ABS if needed
    safetySystem.activateAbs(speed, amount);
    
    // Update speed (assuming deltaTime = 1 second for simplicity)
    double oldSpeed = speed;
    double newSpeed = speed - deceleration * 3.6;  // Convert m/s² to km/h
    
    // Ensure speed doesn't go below 0
    setSpeed(newSpeed);
    
    // Apply regenerative braking to charge battery
    double regenAmount = amount * drivingMode.getRegenerativeBrakingFactor() * 0.005;
    battery.charge(regenAmount);
    
    return oldSpeed - speed;
}

bool Vehicle::pressBrake(double seconds) {
    // Increment brake press time
    brakePressTime += seconds;
    
    // Apply brakes
    brake(0.5);  // Medium brake force
    
    // Check if brake has been pressed for at least 3 seconds
    if (brakePressTime >= 3.0 && parkingBrake) {
        // Release parking brake after 3 seconds as per Operation.md requirement 1
        parkingBrake = false;
        display.addMessage("Parking brake released", MessageType::INFO);
        return true;
    }
    
    return false;
}

bool Vehicle::changeDrivingMode(DrivingModeType mode) {
    // Get current and new mode max speed limits
    double currentModeLimit = drivingMode.getMaxSpeedLimit();
    double newModeLimit = drivingMode.getMaxSpeedLimit(mode);
    
    // Check if current speed exceeds new mode's limit as per Operation.md requirement 5
    if (speed > newModeLimit) {
        display.addMessage("Cannot change mode at high speed", MessageType::WARNING);
        return false;
    }
    
    // Change mode
    drivingMode.setCurrentMode(mode);
    
    // Update current max speed
    currentMaxSpeed = newModeLimit;
    
    return true;
}

void Vehicle::update(double deltaTime) {
    if (!engineOn) {
        return;
    }
    
    // Update engine temperature
    engine.updateTemperature(environment.getTemperature(), speed / currentMaxSpeed);
    
    // Update battery temperature
    battery.updateTemperature(environment.getTemperature(), speed / currentMaxSpeed);
    
    // Cool down engine
    engine.coolDown(deltaTime);
    
    // Handle engine overheat if necessary
    if (engine.isOverheated()) {
        engine.handleOverheat();
    }
    
    // Monitor battery temperature
    safetySystem.monitorBattery(battery.getTemperature());
    
    // Update sensors
    updateSensors();
    
    // Check for high speed warning
    checkHighSpeed();
    
    // Check seatbelt when moving
    checkSeatbelt();
    
    // Handle automatic speed reduction when changing to a lower speed mode
    // as per Operation.md requirement 4
    if (speed > currentMaxSpeed) {
        // Reduce speed gradually (10 km/h per second)
        double speedReduction = std::min(10.0 * deltaTime, speed - currentMaxSpeed);
        speed -= speedReduction;
    }
    
    // Discharge battery based on speed (simplified model)
    double dischargeFactor = speed / currentMaxSpeed * 0.001;
    battery.discharge(dischargeFactor);
}

bool Vehicle::checkSeatbelt() {
    // Check seatbelt when moving as per Operation.md requirement 3
    if (!seatbeltOn && speed > 0) {
        display.addMessage("Seatbelt not fastened", MessageType::WARNING);
        return false;
    }
    
    return seatbeltOn;
}

bool Vehicle::checkDoorLock() {
    return doorLocked;
}

bool Vehicle::releaseParkingBrake() {
    // Check if brake has been pressed for at least 3 seconds
    if (brakePressTime >= 3.0) {
        parkingBrake = false;
        return true;
    }
    
    return false;
}

bool Vehicle::checkHighSpeed() {
    // Check for high speed warning as per Operation.md requirement 6
    if (speed > 120.0) {
        display.addMessage("High speed warning", MessageType::WARNING);
        return false;
    }
    
    return true;
}

void Vehicle::initializeSensors() {
    // Create and initialize sensors
    sensors.push_back(Sensor(SensorType::SPEED, 100.0));
    sensors.push_back(Sensor(SensorType::TEMPERATURE, 50.0));
    sensors.push_back(Sensor(SensorType::VOLTAGE, 50.0));
    sensors.push_back(Sensor(SensorType::CURRENT, 50.0));
    sensors.push_back(Sensor(SensorType::PROXIMITY, 50.0));
    sensors.push_back(Sensor(SensorType::ACCELERATION, 100.0));
}

void Vehicle::updateSensors() {
    // Update sensor readings with current vehicle state
    for (auto& sensor : sensors) {
        switch (sensor.getType()) {
            case SensorType::SPEED:
                sensor.update(speed);
                break;
                
            case SensorType::TEMPERATURE:
                sensor.update(engine.getTemperature());
                break;
                
            case SensorType::VOLTAGE:
                sensor.update(battery.getVoltage());
                break;
                
            case SensorType::CURRENT:
                // Simplified current calculation based on speed
                sensor.update(speed / currentMaxSpeed * 100.0);
                break;
                
            case SensorType::PROXIMITY:
                // Placeholder for proximity sensor
                sensor.update(100.0);
                break;
                
            case SensorType::ACCELERATION:
                // Simplified acceleration calculation
                sensor.update(engine.calculateAcceleration(weight) * 3.6);
                break;
                
            default:
                break;
        }
    }
}

std::string Vehicle::getStatusString() const {
    std::stringstream ss;
    ss << "Vehicle Status:" << std::endl;
    ss << "  Engine: " << (engineOn ? "Running" : "Off") << std::endl;
    ss << "  Doors: " << (doorLocked ? "Locked" : "Unlocked") << std::endl;
    ss << "  Parking Brake: " << (parkingBrake ? "Engaged" : "Released") << std::endl;
    ss << "  Seatbelt: " << (seatbeltOn ? "Fastened" : "Unfastened") << std::endl;
    ss << "  Speed: " << std::fixed << std::setprecision(1) << speed << " km/h" << std::endl;
    ss << "  Max Speed: " << std::fixed << std::setprecision(1) << currentMaxSpeed << " km/h" << std::endl;
    ss << "  Driving Mode: " << drivingMode.getCurrentModeString() << std::endl;
    ss << "  Battery Charge: " << std::fixed << std::setprecision(1) << (battery.getCurrentCharge() * 100.0) << "%" << std::endl;
    ss << "  Estimated Range: " << std::fixed << std::setprecision(1) 
       << battery.calculateRemainingRange(drivingMode.getCurrentMode(), environment) << " km" << std::endl;
    
    return ss.str();
}
