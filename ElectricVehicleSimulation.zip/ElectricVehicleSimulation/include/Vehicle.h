#ifndef VEHICLE_H
#define VEHICLE_H

#include <string>
#include <vector>

#include "Engine.h"
#include "Battery.h"
#include "DrivingMode.h"
#include "SafetySystem.h"
#include "EnvironmentalCondition.h"
#include "FaultSimulation.h"
#include "Display.h"
#include "Sensor.h"

/**
 * @class Vehicle
 * @brief Main class representing the electric vehicle
 */
class Vehicle {
private:
    Engine engine;
    Battery battery;
    DrivingMode drivingMode;
    SafetySystem safetySystem;
    EnvironmentalCondition environment;
    FaultSimulation faultSim;
    Display display;
    
    // Vehicle state variables
    bool engineOn;
    bool doorLocked;
    bool parkingBrake;
    bool seatbeltOn;
    double speed;
    double currentMaxSpeed;
    double brakePressTime;
    double weight;
    
    // Sensors
    std::vector<Sensor> sensors;
    
public:
    /**
     * @brief Default constructor
     */
    Vehicle();
    
    /**
     * @brief Destructor
     */
    ~Vehicle();
    
    // Getters
    bool isEngineOn() const;
    bool isDoorLocked() const;
    bool isParkingBrakeOn() const;
    bool isSeatbeltOn() const;
    double getSpeed() const;
    double getCurrentMaxSpeed() const;
    double getBrakePressTime() const;
    double getWeight() const;
    
    Engine& getEngine();
    Battery& getBattery();
    DrivingMode& getDrivingMode();
    SafetySystem& getSafetySystem();
    EnvironmentalCondition& getEnvironment();
    FaultSimulation& getFaultSim();
    Display& getDisplay();
    
    // Setters
    void setEngineOn(bool state);
    void setDoorLocked(bool state);
    void setParkingBrake(bool state);
    void setSeatbeltOn(bool state);
    void setSpeed(double newSpeed);
    void setBrakePressTime(double time);
    void setWeight(double weight);
    
    // Operations
    /**
     * @brief Start the vehicle engine
     * @return true if engine started successfully, false otherwise
     */
    bool startEngine();
    
    /**
     * @brief Stop the vehicle engine
     */
    void stopEngine();
    
    /**
     * @brief Accelerate the vehicle
     * @param amount Acceleration amount (0-1)
     * @return Actual speed increase
     */
    double accelerate(double amount);
    
    /**
     * @brief Apply brakes to slow down the vehicle
     * @param amount Brake force (0-1)
     * @return Actual speed decrease
     */
    double brake(double amount);
    
    /**
     * @brief Press and hold brake pedal for a specific time
     * @param seconds Time to press brake in seconds
     * @return true if brake was pressed for the specified time, false otherwise
     */
    bool pressBrake(double seconds);
    
    /**
     * @brief Change driving mode
     * @param mode New driving mode
     * @return true if mode change was successful, false otherwise
     */
    bool changeDrivingMode(DrivingModeType mode);
    
    /**
     * @brief Update vehicle state based on elapsed time
     * @param deltaTime Time elapsed in seconds
     */
    void update(double deltaTime);
    
    // Safety checks
    /**
     * @brief Check seatbelt status and issue warning if needed
     * @return true if seatbelt is fastened, false otherwise
     */
    bool checkSeatbelt();
    
    /**
     * @brief Check door lock status
     * @return true if doors are locked, false otherwise
     */
    bool checkDoorLock();
    
    /**
     * @brief Release parking brake
     * @return true if parking brake was released, false otherwise
     */
    bool releaseParkingBrake();
    
    /**
     * @brief Check for high speed and issue warning if needed
     * @return true if speed is within safe limits, false otherwise
     */
    bool checkHighSpeed();
    
    /**
     * @brief Initialize sensors
     */
    void initializeSensors();
    
    /**
     * @brief Update sensors with current vehicle state
     */
    void updateSensors();
    
    /**
     * @brief Get vehicle status as string
     * @return Status string
     */
    std::string getStatusString() const;
};

#endif // VEHICLE_H
